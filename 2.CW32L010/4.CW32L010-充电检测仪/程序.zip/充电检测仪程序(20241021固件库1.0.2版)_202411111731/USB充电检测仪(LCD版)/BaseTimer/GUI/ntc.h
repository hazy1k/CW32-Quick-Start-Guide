#ifndef __NTC_H
#define __NTC_H		

#include "cw32l010.h"
 
unsigned int GetNTCTable_Temp(float Vout);

#endif

